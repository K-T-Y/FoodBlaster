<?php
$username="id20521955_root";
$password="FoodBlaster@1234";
$dbname="id20521955_food_blaster";
$hostname="localhost";
$con=mysqli_connect($hostname,$username,$password,$dbname);




?>